# WATCH HUNTER V3 — radar sans Gmail

Un petit site gratuit qui **interroge automatiquement un index public de recherche** pour repérer des pages d'annonces Vinted et Leboncoin relatives aux montres. Le site classe les liens, élimine les doublons et met en avant ceux dont un prix de **15 € maximum apparaît dans l'extrait**. Aucun achat, aucune connexion aux comptes des plateformes, aucun e-mail.

**IMPORTANT :** ce n'est PAS une surveillance exhaustive ou en temps réel des annonces Vinted et Leboncoin. Ces plateformes restreignent la collecte automatisée directe. Le projet repose sur la disponibilité d'un flux RSS de Bing et sur son index, qui peut refuser les requêtes, être incomplet, ancien ou supprimer son service à tout moment. Le site montre honnêtement les erreurs, et ne fabrique pas d'annonces. Les prix, l'état, la disponibilité et l'authenticité doivent être vérifiés sur les sites d'origine. Le score est seulement un classement par mots-clés ; **ce n'est pas un prix de revente**.

## Installer (idéalement dans un navigateur d'ordinateur, environ 20 à 30 minutes)

1. Décompresse `watch-hunter-v3.zip` ; conserve bien les dossiers `public/` et `.github/workflows/`.
2. Va sur https://github.com/new et crée un dépôt **public** nommé `watch-hunter` avec la branche `main`. Ne coche pas « Add a README » si tu vas envoyer tous les fichiers immédiatement.
3. Dans ce dépôt, fais **Add file → Upload files** puis dépose tout le contenu du dossier décompressé en conservant l'arborescence (notamment `.github/workflows/watch-hunter.yml`, `public/index.html`, `public/data.json`, `scanner.py`). Si le navigateur refuse les dossiers, utilise Git ou crée séparément les chemins nécessaires dans l'éditeur Web de GitHub.
4. Va dans **Settings → Pages → Build and deployment → Source : GitHub Actions**. Enregistre.
5. Va dans **Actions → Watch Hunter - radar autonome → Run workflow** et clique pour lancer le premier scan, si celui-ci n'a pas déjà démarré lors de l'ajout des fichiers.
6. Quand l'exécution est terminée, ton lien sera généralement `https://TON-PSEUDO.github.io/watch-hunter/`. Tu peux le mettre sur l'écran d'accueil de ton téléphone.

**Attention pour GitHub sur téléphone :** pour envoyer une structure de dossiers comprenant `.github/`, la version ordinateur du site GitHub est généralement plus pratique. Sur mobile, active l'option « Site pour ordinateur » du navigateur ou utilise une application Git. Ne téléverse pas le ZIP tel quel : GitHub ne le décompresse pas automatiquement.

## Ce qui tourne tout seul

- Chaque heure (à :17 approximativement), GitHub Actions lance `scanner.py` sur ses serveurs.
- Le scanner alterne les mots-clés : quatre à chaque passage et par plateforme, les vingt mots-clés sont couverts sur cinq passages.
- Il interroge un flux RSS du moteur Bing avec des requêtes `site:vinted.fr/items` et `site:leboncoin.fr/ad` ; **il ne télécharge pas les pages des plateformes**.
- Les URL repérées sont dédupliquées. Si un prix supérieur à 15 € est **indiqué dans l'extrait**, le lien est exclu. Si le prix n'apparaît pas, la piste est rangée dans « Prix inconnus ».
- Les résultats sont conservés jusqu'à 14 jours depuis leur dernière apparition, puis publiés dans `public/data.json`.
- Le site affiche les listes, les filtres, les favoris locaux, l'heure du dernier passage et les erreurs de sources éventuelles.

## Comprendre les limites

- Une annonce récente peut ne pas être indexée par Bing ; une annonce vendue peut y rester.
- `15 €` trouvé dans un extrait n'est **pas une confirmation fiable** du prix réel ; vérifie sur la plateforme avant de décider.
- Les pages peuvent être absentes du moteur, ou le flux RSS peut cesser de répondre ; le tableau de bord le signalera.
- Les moteurs de recherche ne donnent pas nécessairement les photos ; la version V3 n'affiche donc pas de fausses photos.
- Le bouton « Actualiser » du site recharge **les données déjà publiées** ; il ne déclenche pas instantanément la recherche côté serveur.
- GitHub peut retarder des scans programmés et désactiver les workflows programmés sur un dépôt public resté inactif pendant 60 jours.
- Les résultats sont publiquement visibles si ton dépôt GitHub Pages est public ; aucun nom, adresse ou mot de passe n'est stocké.

## Modifier les recherches

Dans `scanner.py` : `SEARCH_TERMS` contient les 20 recherches, `MAX_PRICE` le plafond. Si tu modifies le plafond, pense à adapter le texte du site dans `public/index.html`.

## Déboguer

- Si le site affiche « Le robot n'a pas encore démarré » : vérifie **Actions**, lance `Run workflow` et confirme que le déploiement Pages est autorisé.
- Si les sources affichent « indisponibles » : clique sur la dernière exécution de workflow dans Actions pour voir les erreurs réseau. Cela peut être temporaire ou venir d'une limitation de Bing.
- Si le scan marche mais donne 0 lien : cela peut être normal, Bing n'ayant pas forcément de pages d'annonces pertinentes dans ses résultats ; aucune annonce d'exemple n'est injectée.
- Si les nouveaux résultats n'apparaissent pas : vérifie la date du dernier scan et recharge le site.

## Vérifier le programme sans Internet

```
python -m unittest discover -s tests -v
```

Tous les tests de parsing, prix et filtrage fonctionnent sans réseau. Les requêtes réseau réelles doivent être testées dans le dépôt GitHub une fois le workflow installé.

### Documentation officielle

- https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
- https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows
- https://www.vinted.com/terms-and-conditions
- https://www.leboncoin.fr/dc/cgu
