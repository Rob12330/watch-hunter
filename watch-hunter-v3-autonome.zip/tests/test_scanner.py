import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import scanner

class TestScanner(unittest.TestCase):
    def test_direct_links(self):
        self.assertEqual(scanner.clean_url('https://www.vinted.fr/items/12345-my-watch?utm_source=foo'), ('https://www.vinted.fr/items/12345-my-watch', 'Vinted'))
        self.assertEqual(scanner.clean_url('https://www.leboncoin.fr/ad/montres_bijoux/3123456789?x=1'), ('https://www.leboncoin.fr/ad/montres_bijoux/3123456789', 'Leboncoin'))
        self.assertEqual(scanner.clean_url('https://vinted.fr/catalog?search_text=montre'), (None,None))
        self.assertEqual(scanner.clean_url('https://evil.com/items/123'), (None,None))
    def test_prices(self):
        self.assertEqual(scanner.extract_price('Seiko vintage 12 €', 'test'), (12,'titre'))
        self.assertEqual(scanner.extract_price('Seiko vintage', 'Prix 9,50 euros'), (9.5,'extrait'))
        self.assertEqual(scanner.extract_price('Seiko vintage', 'sans prix'), (None,'inconnu'))
    def test_filter(self):
        t='2026-10-11T18:00:00Z'
        p=scanner.parse_result({'title':'Omega vintage 12 €','description':'Montre ancienne','url':'https://www.vinted.fr/items/123'} ,t)
        self.assertEqual(p['price'],12)
        self.assertFalse(p['is_verified'])
        self.assertIsNone(scanner.parse_result({'title':'Montre vintage 20 €','description':'','url':'https://www.vinted.fr/items/124'},t))
        self.assertIsNotNone(scanner.parse_result({'title':'montre ancienne','description':'','url':'https://www.leboncoin.fr/ad/montres_bijoux/123'},t))
    def test_rss(self):
        xml=b'<rss><channel><item><title>Montre 10 &amp; remontoir</title><link>https://www.vinted.fr/items/45</link><description>10 euros</description></item></channel></rss>'
        it=list(scanner.rss_items(xml))
        self.assertEqual(len(it),1)
        self.assertIn('&',it[0]['title'])
    def test_no_markup_in_title(self):
        self.assertEqual(scanner.clean_text('<b>Vintage</b> &amp; luxe'), 'Vintage & luxe')

if __name__=='__main__': unittest.main()
